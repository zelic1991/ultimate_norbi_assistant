# Ultimate Code-Studio Roadmap

Dieser Plan fasst die nächsten Schritte für deinen Programmier‑Assistenten zusammen, basierend auf den Informationen aus den bereitgestellten ZIP‑Archiven (wichtig.zip, wichtige_chats.zip) und dem aktuellen Entwicklungsstand.

## Zusammenfassung der Inhalte

- **wichtig.zip**: Enthält die Basis des „Nobby Assistant Patch V1“ mit einer klaren Services‑Schicht, OpenAI‑Proxy, STT/TTS‑Integration, sicheren Dateizugriffen (Root‑Sandbox), Terminal‑Adapter, Audit‑Skripte und einer minimalen VS‑Code‑Extension.  Der Patch legt Wert auf Telemetrie: Laufzeitmessungen, Logging und sichere Freigaben.
- **wichtige_chats.zip**: Sammlung von Analyse‑Skripten (Chat‑Clustering, Duplikat‑Scan, Filter), JSON‑Reports und Dokumenten, die Policies, DoD‑Definitionen und Hinweise auf Freigaben enthalten.  Diese Chats liefern Stil‑ und Prozess‑Signale für deinen Agenten.

Aus diesen Quellen wurden drei Dateien erzeugt:

- `docs_preview.txt` – ein kurzer Textauszug mit den wichtigsten Signalen.
- `policy_seed.yaml` – eine Start‑Policy, die Ton, Prioritäten und Guardrails definiert.
- `extracted_inventory.csv` – ein Inventar der extrahierten Dateien (nicht enthalten, da in dieser Session nicht reproduziert).


## Kernpunkte der Policy‑Seed

- **Ton & Stil**: Unternehmerisch, klar, motivierend; nur eine präzise Rückfrage pro Auftrag.
- **Workflow**: `Plan → Explore → Compare → Simulate → Propose → Approve → Execute → Verify → Learn`.
- **Scorecard**: Impact, Effort↓, Risk↓, Reversibility, Cost↓, Maintainability.
- **Guardrails**: Arbeiten nur in freigegebenen Verzeichnissen, keine direkten Löschungen ohne Voransicht („What‑If“), keine Secrets im Klartext.
- **Funktionen**: Datenhygiene (Compress, Dedupe, Validate), Telemetrie‑Logging, STT/TTS‑Anbindung, Audit‑Skripte, Terminal‑Adapter; alles mit Metriken instrumentiert.


## Roadmap (Phasen zum Abhaken)

| Phase | Fokus | Deliverables | KPI | Status |
|---|---|---|---|---|
| **0 – Fundament** | Ordnerstruktur, Scheduler, Logs, Digest | RAW/CURRENT/ARCHIVE/Policies; Wartungsskripte; Maintenance‑Tasks (Daily, Hourly, OnStartup); Digest | Logs vorhanden, Digest läuft | ✅ abgeschlossen |
| **1 – Code‑Studio‑Kernel** | Code‑Generator `codegen.py`, Runner `run_codegen.ps1`, Policy & Prompts | Dateien existieren und schreiben Logs; Code‑Preview zeigt ersten Entwurf | Codegen‑Runs ≥ 1 / Tag; Fehlerquote ≈ 0 | 🟩 70 % |
| **2 – Critic‑Schleife** | Entwurf vor dem Schreiben prüfen (Spez‑Erfüllung, Risiken, Alternativen) | Kritischer Pass in `codegen.py`; Risiko‑Ampel im Draft | „Approve ohne Rollback“ ≥ 99 %; Critic‑Coverage = 100 % | 🟨 geplant |
| **3 – Approval‑Flow** | Freigaben per VS Code / Telegram | tasks.json für VS Code (Preview/Write), Bot‑Commands `/approve` | Decision→Action‑Zeit ↓, manuelle Korrekturen ≈ 0 | 🟨 geplant |
| **4 – Templates & Audits** | Vorlage‑Bibliothek (FastAPI, React) & Audit‑Skripte integrieren | Template‑Files, audit_runner; Wiederverwendungsrate ≥ 60 % | 🟨 geplant |
| **5 – Telemetrie & KPIs** | Logging & Messungen für Codegen & Audits | `progress.jsonl`, wöchentlicher KPI‑Digest | Messbare Latenz & Fehlerquote | 🟨 geplant |
| **6 – Lernen & Glossar** | Glossar-Datei & Korrektur‑Feedback | Glossar, Lernregeln, Terminologie (Kelly‑Light, CLV) | Intent‑Accuracy ≥ 98 %, Rückfragenquote ↓ | 🟨 geplant |


## Nächste Schritte

1. **Policy‑Merge vorbereiten**: Sicherung deiner bestehenden `POLICIES/codegen_policy.yaml` und Zusammenführung mit `policy_seed.yaml` (Scorecard, Guardrails, Stil).  Prüfe per Diff, welche Regeln neu hinzukommen.
2. **Code‑Test (Preview)**: Erstelle eine kleine Spezifikation (z. B. „Baue eine FastAPI‑App mit Healthcheck“) und führe `run_codegen.ps1 -Dry` aus.  Der Agent sollte einen Plan, Optionen mit Scorecard, Risiko‑Ampel und einen Entwurf liefern (ohne Schreiben).
3. **Critic‑Hook integrieren**: Nach dem Entwurf kontrolliert der Agent selbst, ob Spezifikation erfüllt ist, Risiken nennt, Alternativen bietet und DoD einhält.  Ausgabe ins Log.
4. **Approval‑Mechanismus**: Definiere VS‑Code‑Tasks („Preview“, „Write“) und setze einen Telegram‑Bot auf.  Nur nach `/approve` schreibt der Agent den Code in `CURRENT/`.
5. **Audit‑Skripte**: Nutze die Scripts aus wichtig.zip (z. B. `audit_repo.py`, `duplicate_finder.py`) als Vorlage.  Integriere sie in deinen Agenten, der sie mit Preview/Approve ausführt.
6. **Glossar & Lernregeln**: Erstelle eine Glossar-Datei mit deinen häufigen Abkürzungen/Begriffen (Kelly‑Light, CLV, „30‑Punkte“) und implementiere Korrektur‑Feedback (Learn‑Loop).  Einmal pro Woche sollten diese Regeln überprüft und veraltete entfernt werden.


## Dateien in diesem Paket

- **plan.md** (dieses Dokument) – Roadmap & Zusammenfassung.
- **policy_seed.yaml** – Start‑Policy mit Stil, Scorecard und Guardrails.
- **docs_preview.txt** – Zusammenfassung der wichtigsten Signale aus den hochgeladenen ZIP‑Files (s. nächste Seite).

