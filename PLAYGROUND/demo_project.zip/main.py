﻿print('hello from skeleton')
